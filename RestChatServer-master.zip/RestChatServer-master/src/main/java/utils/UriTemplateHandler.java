package utils;

import org.webbitserver.HttpControl;
import org.webbitserver.HttpHandler;
import org.webbitserver.HttpRequest;
import org.webbitserver.HttpResponse;

import java.net.URI;
import java.util.Map;

public class UriTemplateHandler implements HttpHandler {

    public static final String URI_MATCH = "URI_MATCH";

    private final HttpHandler httpHandler;
    private final String uriTemplate;
    private final UriTemplateEngine uriTemplateEngine;

    public UriTemplateHandler(String uriTemplate, HttpHandler httpHandler, UriTemplateEngine uriTemplateEngine) {
        this.uriTemplate = uriTemplate;
        this.uriTemplateEngine = uriTemplateEngine;
        this.httpHandler = httpHandler;
    }

    @Override
    public void handleHttpRequest(HttpRequest request, HttpResponse response, HttpControl control) throws Exception {
        String path = URI.create(request.uri()).getPath();

        Map<String, Object> variables = uriTemplateEngine.extract(uriTemplate, path);
        if (variables != null) {
            request.data(URI_MATCH, variables);
            httpHandler.handleHttpRequest(request, response, control);
        } else {
            control.nextHandler();
        }
    }
}
