furi-0.8.4.jar is from http://code.google.com/p/wo-furi/ and is licensed under Artistic License/GPL
